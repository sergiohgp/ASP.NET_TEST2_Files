﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Test2_Sergio_Pereira.Controllers
{
    public class TicketsController : Controller
    {

        SqlConnection connection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\2. Cloud\OneDrive - Lambton College\3rd Term\CSD 3354 Web Apps C# .Net\CSharp_dotNet_Projects\Passengers\Passengers\App_Data\SSAirline.mdf';Integrated Security=True");
        // GET: Tickets
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string lastName, int quantity, string date, string showName)
        {
            return Content($"{lastName}, your ticket was booked successfully to the {showName} on {date}. Quantity booked: {quantity}");
        }
    }
}