﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test2_Sergio_Pereira.Models;

namespace Test2_Sergio_Pereira.Controllers
{

    public class UpdateTicketsController : Controller
    {
        SqlConnection connection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename='D:\2. Cloud\OneDrive - Lambton College\3rd Term\CSD 3354 Web Apps C# .Net\CSharp_dotNet_Projects\Passengers\Passengers\App_Data\SSAirline.mdf';Integrated Security=True");
        // GET: UpdateTickets
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Reservation(Tickets tickets)
        {
            if(connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }

            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = $"insert into Table (FirstName, LastName, Phone, Address, Date, ShowName, Quantity" +
                    $"values('{tickets.firstName}', '{tickets.lastName}', '{tickets.phone}', '{tickets.address}', '{tickets.date}', '{tickets.quantity}'";

                try
                {
                    command.ExecuteNonQuery();
                    connection.Close();
                    return View();
                }
                catch (Exception e)
                {
                    return Content($"Error: {e.Message}");
                }
            }

            return Content("Error: Could not connect to the database");
        }

        public ActionResult TicketsInfo()
        {
            return View();
        }

        // GET: UpdateTickets/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UpdateTickets/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UpdateTickets/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: UpdateTickets/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: UpdateTickets/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: UpdateTickets/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UpdateTickets/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
