﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Test2_Sergio_Pereira.Models
{
    public class Tickets
    {
        public int ID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int phone { get; set; }
        public string address { get; set; }
        public string showName { get; set; }
        public string date { get; set; }
        public Quantity quantity { get; set; }
    }

}

public enum Quantity
    {
      one,
      two,
      three,
      four,
      five
    }
}